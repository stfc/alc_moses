#!/bin/bash
## Submission script for scarf
#SBATCH --job-name=sol-cp2k    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=1-00:00:00        # days-hh:mm:ss
#
#SBATCH --partition=scarf    # queue (partition)
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=2
 
export OMP_NUM_THREADS=2
 
## Load required modules
module load CP2K/2023.1-foss-2023a
 
## Define executable
exec="cp2k"
 
## Execute job
mpirun -np 16 $exec -i input.cp2k -o output.cp2k
