#!/bin/bash
## Submission script for scarf
#SBATCH --job-name=gcdft-onetep    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=1-00:00:00        # days-hh:mm:ss
#
#SBATCH --partition=scarf    # queue (partition)
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=2
 
export OMP_NUM_THREADS=2
 
## Load required modules
module load load_modules_amd_foss2025a
 
## Define executable
exec="/home/vol08/scarf628/codes/ONETEP/onetep/bin/onetep.scarf.amd_gfortran"
 
## Execute job
mpirun -np 16 $exec  model.dat > model.out
